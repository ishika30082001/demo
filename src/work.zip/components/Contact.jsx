import React from 'react'

function Contact() {
  return (
    <>
     <h1>Contact page</h1> 
    </>
  )
}

export default Contact
