import React from 'react'

function ShopDetail() {
  return (
    <>
     <h1>Shop Detail page</h1> 
    </>
  )
}

export default ShopDetail
